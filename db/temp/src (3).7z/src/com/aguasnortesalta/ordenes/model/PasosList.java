package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class PasosList extends BaseList{
	 public List< Pasos> data= null;
}
