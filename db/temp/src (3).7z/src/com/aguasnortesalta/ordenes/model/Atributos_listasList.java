package com.aguasnortesalta.ordenes.model;

            import java.util.List;

            public class Atributos_listasList extends BaseList {
                public List< Atributos_listas> data= null;

            }
