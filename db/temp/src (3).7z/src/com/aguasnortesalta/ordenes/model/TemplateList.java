package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class TemplateList extends BaseList{
    public List< Template> data= null;
}
