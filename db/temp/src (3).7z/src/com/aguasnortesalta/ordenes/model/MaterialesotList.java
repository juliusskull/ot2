package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class MaterialesotList extends BaseList{
	public List< Materialesot> data= null;
}
