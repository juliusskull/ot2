package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class ServiciosxmotivoList extends BaseList{
	public List< Serviciosxmotivo> data= null;
}
