package com.aguasnortesalta.ordenes.model;

            import java.util.List;

            public class ComponentesxatributosList extends BaseList {
                public List< Componentesxatributos> data= null;

            }
