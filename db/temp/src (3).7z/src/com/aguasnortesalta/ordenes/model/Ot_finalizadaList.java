package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class Ot_finalizadaList extends BaseList {
	public List< Ot_finalizada> data= null;
}
