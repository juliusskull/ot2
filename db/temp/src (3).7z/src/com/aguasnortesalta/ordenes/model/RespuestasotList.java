package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class RespuestasotList extends BaseList {
	public List< Respuestasot> data= null;
	
}
