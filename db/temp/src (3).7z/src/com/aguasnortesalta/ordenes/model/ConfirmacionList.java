package com.aguasnortesalta.ordenes.model;

            import java.util.List;

            public class ConfirmacionList extends BaseList {
                public List< Confirmacion> data= null;

            }
