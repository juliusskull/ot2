package com.aguasnortesalta.ordenes.model;

            import java.util.List;

            public class ArchivoList extends BaseList {
                public List< Archivo> data= null;

            }
