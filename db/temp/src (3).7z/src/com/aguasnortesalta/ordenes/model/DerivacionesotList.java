package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class DerivacionesotList extends BaseList{
	public List<Derivacionesot> data= null;
}
