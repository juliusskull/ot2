package com.aguasnortesalta.ordenes.model;

import java.util.List;
public class EditorList extends BaseList {
	
	public List<Editor> data= null;
}
