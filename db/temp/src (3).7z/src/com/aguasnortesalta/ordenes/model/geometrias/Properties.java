package com.aguasnortesalta.ordenes.model.geometrias;

public class Properties {
	
	public long featid;	
	public String titulo;
	public String descripcion;
	public String material;
	public long id_categoria;
	public long id_tipo_servicio;
	public long id_tipo_componente;
	
}
