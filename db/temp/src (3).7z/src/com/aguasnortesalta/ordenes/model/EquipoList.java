package com.aguasnortesalta.ordenes.model;

import java.util.List;

public class EquipoList extends BaseList{
	public List< Equipo> data= null;
}
