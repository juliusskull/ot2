package com.aguasnortesalta.ordenes.model;

            import java.util.List;

            public class Atributosxtipo_componenteList extends BaseList {
                public List< Atributosxtipo_componente> data= null;

            }
