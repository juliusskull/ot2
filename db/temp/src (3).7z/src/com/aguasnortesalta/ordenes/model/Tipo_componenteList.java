package com.aguasnortesalta.ordenes.model;

            import java.util.List;

            public class Tipo_componenteList extends BaseList {
                public List< Tipo_componente> data= null;

            }
