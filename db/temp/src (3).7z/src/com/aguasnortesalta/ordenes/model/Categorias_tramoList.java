package com.aguasnortesalta.ordenes.model;

            import java.util.List;

            public class Categorias_tramoList extends BaseList {
                public List< Categorias_tramo> data= null;

            }
