/* prueba localhost */
//www="http://10.0.2.2/ot/ot/";
/* prueba localhost */
//www="http://localhost/ot/ot/";
/* produccion */
//www="http://ot.aguasdelnortesalta.com.ar/";
/*
origen_ot="http://ot.aguasdelnortesalta.com.ar/wses.php?lot=0";
origen_rastreo="http://ot.aguasdelnortesalta.com.ar/wses.php?lrastreo=0";
*/

origen_ot="../wses.php?lot=0";
origen_rastreo="../wses.php?lrastreo=0";