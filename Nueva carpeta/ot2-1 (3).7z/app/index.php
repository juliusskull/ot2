<?php

require_once '../controler/pasosControler.php';
require_once '../controler/operarioControler.php';
require_once '../controler/templateControler.php';
require_once '../controler/pasosxtemplateControler.php';
require_once '../controler/otControler.php';
require_once '../controler/sincronizarControler.php';
require_once '../controler/ot_finalizadaControler.php';
require_once '../controler/ot_finalizada_valorControler.php';
require_once '../controler/ot_finalizar_viewControler.php';
require_once '../controler/mapaControler.php';
require_once '../controler/template_viewControler.php';
